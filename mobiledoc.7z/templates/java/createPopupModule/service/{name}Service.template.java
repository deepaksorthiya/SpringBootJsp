package ${packagePath}.service;
/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 */
import java.util.List;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.beans.factory.annotation.Autowired;

import inpatientWeb.utils.TransactionUtil;
import inpatientWeb.${parentModule}.${appNameVar}.model.${appName};
import inpatientWeb.${parentModule}.${appNameVar}.dao.${appName}Dao;

@Service
@Lazy
public class ${appName}Service {
	
	@Autowired
	private ${appName}Dao ${appNameVar}Dao;
	
	@Autowired
	private TransactionUtil transactionUtil;
	
	public ${appName} get(int id) {
		return ${appNameVar}Dao.get(id);
	}
	
	public boolean save(${appName} ${appNameVar}) {
		boolean isSuccess = false;
		TransactionStatus status = transactionUtil.getTransactionStatus();
		try {
			${appNameVar}Dao.save(${appNameVar});
			isSuccess = true;
			transactionUtil.getTransactionManager().commit(status);
		} catch (Exception e) {
			transactionUtil.getTransactionManager().rollback(status);
			isSuccess = false;
		}
		return isSuccess;
	}

	public List<${appName}> getAll() {
		return ${appNameVar}Dao.getAll();
	}

	public ${appName} update(${appName} ${appNameVar}) {
		// TODO Auto-generated method stub
		return ${appNameVar}Dao.update(${appNameVar});
	}

	public void delete(int id) {
		// TODO Auto-generated method stub
		${appNameVar}Dao.delete(id);
	}
}