package ${packagePath}.dao;
/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 */
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import inpatientWeb.${parentModule}.${appNameVar}.model.${appName};

@Repository
@Lazy
public class ${appName}DaoImpl implements ${appName}Dao {
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Override
	public ${appName} get(int id) {
		// TODO Auto-generated method stub
		${appName} ${appNameVar} = new ${appName}();
		${appNameVar}.setId(id);
		${appNameVar}.setName("This is default name.");
		return ${appNameVar};
	}
	
	@Override
	public boolean save(${appName} ${appNameVar}) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public List<${appName}> getAll() {
		// TODO Auto-generated method stub
		return new ArrayList<>();
	}

	@Override
	public ${appName} update(${appName} ${appNameVar}) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int ${appNameVar}Id) {
		// TODO Auto-generated method stub
	}
}