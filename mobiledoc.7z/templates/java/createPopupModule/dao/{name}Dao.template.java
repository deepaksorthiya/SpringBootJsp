package ${packagePath}.dao;
/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 */
import java.util.List;
import inpatientWeb.${parentModule}.${appNameVar}.model.${appName};

public interface ${appName}Dao {
	
	public ${appName} get(int id);
	
	public boolean save(${appName} ${appNameVar});

	public List<${appName}> getAll();

	public ${appName} update(${appName} ${appNameVar});

	public void delete(int id);
}