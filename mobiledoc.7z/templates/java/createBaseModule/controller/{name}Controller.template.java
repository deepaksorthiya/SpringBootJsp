package ${packagePath}.controller;
/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import inpatientWeb.${parentModule}.${appNameVar}.model.${appName};
import inpatientWeb.${parentModule}.${appNameVar}.service.${appName}Service;

@Controller
@Lazy
public class ${appName}Controller {
	
	@Autowired
	private ${appName}Service ${appNameVar}Service;
	
	@RequestMapping(value="/${appName}.go/${appNameVar}", method=RequestMethod.GET)
	public String getView() throws Exception {
		return "${parentModule}/${appNameVar}/${appNameVar}";
	}
	
	@RequestMapping(value="/${appName}.go/{id}", method=RequestMethod.GET)
	@ResponseBody
	public ${appName} get(@PathVariable("id") int id){
		return ${appNameVar}Service.get(id);
	}
	
	@RequestMapping(value = "/${appName}.go", method = RequestMethod.GET)
	@ResponseBody
	public List<${appName}> getAll() {
		return ${appNameVar}Service.getAll();
	}
	
	@RequestMapping(value="/${appName}.go/{id}", method={RequestMethod.POST})
	@ResponseBody
	public boolean save(@RequestBody ${appName} ${appNameVar}){
		return ${appNameVar}Service.save(${appNameVar});
	}
	
}