// test case generated on ${generated}
package $pkg
<% imports.each {im-> %>$im<% } %>
import spock.lang.Specification
import spock.lang.Ignore
class ${simpleClzName}Spec extends Specification {
	<%def serviceReference =toCamelCase(simpleClzName) %>
	private ${simpleClzName} <% print(serviceReference)%> = new ${simpleClzName}();
	<% objectsToMock.each {object-> if(object.type.toString() == 'TransactionUtil'){ %>
	TransactionUtil transactionUtil;<% }else{ %>
	$object.type <% print(object.name)%> = Mock(${object.type}.class);<% } %>
	<% def nIndex,methodDesc } %>
	def setup() {
	<% objectsToMock.each {object-> if(object.type.toString() == 'TransactionUtil'){ %>	
		transactionUtil = Stub(TransactionUtil) {
			 getTransactionStatus() >> Mock(TransactionStatus)
			 getTransactionManager() >> Mock(PlatformTransactionManager)
		 }<% } %>
		<% print(serviceReference+"."+ object.name+ "=" +object.name+";")%>
	<% def nIndex,methodDesc } %>
	}
    <% methods.each {method-> %>
	<% nIndex = methodCounts.containsKey(method.name.toString()) ?  methodCounts.get(method.name.toString()) : 0
		methodDesc = "Test  "+simpleClzName+"."+method.name+" method returns correct values"
		if(nIndex > 1) methodDesc+=" :Implementation: "+(nIndex-1)
	 %>	 
	def '${methodDesc}'() {
        <% def isStatic
            if(method.getDeclarationAsString().contains('static')){
                isStatic = true
            } %>
        given:"${isStatic?"Class reference to":"An instance of"} $simpleClzName ${method.parameters.size()>0?"and parameters ":""}${method.parameters.join(",")}"
            <%
                    paramDeclaration=""
					suppliedInputs = ''
            if(method.getParameters().size()>0){
                    method.getParameters().each { param ->
                        paramDeclaration+="${param.getId().getName().toString()} \n\t\t\t"
						if(suppliedInputs.toString().length() > 0) suppliedInputs += '\t\t'
						suppliedInputs += param.getId().getName().toString()+'\t\t |'
                    }
                }
            %>$paramDeclaration
        when:"${simpleClzName}.${method.getName().toString()} is called"
            <%
            String declaration
//                if(isStatic){
                declaration = serviceReference+"."+method.getName().toString()
                //println "---->"+method.getParameters().size()
                if(method.getParameters().size()==0){
                    declaration+="()"
                }else{
                    //println method.getParameters().size()
                    declaration+="("

                    method.getParameters().each{param->
                        declaration+=","+param.getId().getName().toString()
                    }
                    declaration=declaration.replaceFirst(",","")
                    declaration+=")"
//                    }
            }  
			if("void".equals(method.getType().toString())){ %>$declaration
			<% }else{print "def result = $declaration"} %>
        then:"TODO: ADD EXPECTED BEHAVIOUR" // TODO: Edit expected behavior and remove this comment
			<% if(suppliedInputs.toString().length() > 0){%>
		where:"Provided Values are,"
			<%print "$suppliedInputs| \t\t expectedResult"} %>
    }
	<%methodCounts.put(method.name.toString(), --nIndex)%>
        <%} %>
	
	<%
	def toCamelCase( String text ) {		
		return Character.toLowerCase(text.charAt(0)).toString()+ text.substring(1)
	}
	%>
}

