/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 * Use		:
 * 		1. JS dependencies in ipJsDependencies.js
 * 			'${appNgCtrlPath},${appNgServPath}',
 * 		2. Inject '${appNameVar}App' module in base screen app
 * 		3. Use element <${directiveName}></${directiveName}> in base screen jsp
 */
/*----PLEASE DO NOT WRITE ANY JS CODE ABOVE THIS LINE----*/
(function(){
	'use strict';
	var ${appNameVar} = ${appNameVar};
	var ${appNameVar}Controller = ${appNameVar}Controller;
	// All the required dependencies of '${appName}' will go in this array
	var dependencies = [
		'oc.lazyLoad',
		'ui.bootstrap',
		'inPatient.dir.showmessage',
		'ngResource'
    ];
	
	angular.module('${appNameVar}App', dependencies)
	.directive('${appNameVar}', ${appNameVar})
	
	${appNameVar}.\$inject = ['\$modal', '\$ocLazyLoad'];
	function ${appNameVar}(\$modal, \$ocLazyLoad){
		${appNameVar}Controller.\$inject = ['${appName}', '\$modalInstance', '\$ocLazyLoad', '\$resource'];
	    function ${appNameVar}Controller(${appName}, \$modalInstance, \$ocLazyLoad, \$resource){
	    	var vm 							= this;
			vm.${appNameVar}				= {};
			
			// scope functions declaration
			vm.ok 					= ok;
			vm.cancel 				= cancel;
			
			function _init(){
				vm.${appNameVar} = ${appName}.get({ id:1 });
			};
			function ok(){
				vm.${appNameVar}.\$save({},function(result){
					//on success
					\$modalInstance.close();
				}, function(result){
					//on failure
				});
	    	};
			
	    	function cancel(){
	    		\$modalInstance.dismiss();
	    	};
	    	_init();
	    };
	    // To make module as re-usable directive
		return {
	        restrict: 'EA',
			replace : 'true',
	        scope: {
	        	callBackFn: '&onCallBackFn'
	        },
	        template: '<button type="button" class="btn btn-lgrey btn-xs">Open ${appName}</button>',
			bindToController: true,
			controllerAs: 'btnCtrl',
			controller: ['\$element', '\$modal', function(\$element, \$modal){
				var btnCtrl = this;
				var openLookup = function(){
					\$ocLazyLoad.load({
						name: '${appNameVar}App'
					}).then(function(){
						var modalInstance = \$modal.open({
							templateUrl: '${appHtmlPath}',
							controllerAs: 'vm',
							controller: ${appNameVar}Controller,
							backdrop: 'static',
							windowClass	: 'project-10i ${appNameVar}',
							animation: 'true',
							keyboard: false
						});
						modalInstance.result.then(
						function(response) {
							// Parent Callback
							// btnCtrl.callBackFn({response: response});
						}, 
						function() {
							
						})
					}).finally(function(){
						\$modalInstance.dismiss();
					});
				};
				\$element.bind('click',openLookup);
			}]
		};
	}
})();
/*----PLEASE DO NOT WRITE ANY JS CODE BELOW THIS LINE----*/