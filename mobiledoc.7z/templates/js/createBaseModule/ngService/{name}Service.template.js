/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 */
/*----PLEASE DO NOT WRITE ANY JS CODE ABOVE THIS LINE----*/
(function() {
	'use strict';
	angular.module('${appNameVar}App')
		.factory('${appNameVar}Service', ${appNameVar}Service);
	function ${appNameVar}Service(\$resource) {
		 var ${appName} =  \$resource(
				 "/mobiledoc/inpatientWeb/${appName}.go/:id",  
				 { id: "@id" }
			 );
		return ${appName};
	};
})();
/*----PLEASE DO NOT WRITE ANY JS CODE BELOW THIS LINE----*/
