/** 
 * Author	: ${eCWAuthor}
 * Date		: ${generated.format('dd-MM-yyyy')}
 * Template : created using eCW plugin
 * Use		:
 * 		1. in ipJsDependencies.js
 * 			${appNameVar} 			:'${appNgCtrlPath},${appNgServPath}',
 		2. in ipRouter.js : 
 			${appNameVar} 			: 	${parentModule}.getDependencies("${appNameVar}"),
  		3. Edit and run Insert query
  			INSERT  INTO ip_menu_items
			(menuItemName,menuID,itemIconClass,UrlPath,isHidden,deleteFlag,menuOrder,displayName) 
				VALUES 
			('${appName}',(select menuid from ip_menu_list where menuName = '${parentModule}'),'','#r=${appName}.go/${appNameVar}',0,0,(select MAX(menuorder)+1 from ip_menu_items where menuID = (select menuid from ip_menu_list where menuName = '${parentModule}')), '${appName}');
 */
/*----PLEASE DO NOT WRITE ANY JS CODE ABOVE THIS LINE----*/
(function(){
	'use strict';
	var ${appNameVar}Controller = ${appNameVar}Controller;
	
	// All the required dependencies of '${appNameVar}' will go in this array
	var dependencies = [
		'ngResource'
    ];

	angular.module('${appNameVar}App', dependencies)
	.controller('${appNameVar}Controller', ${appNameVar}Controller);
	${appNameVar}Controller.\$inject = ['${appNameVar}Service', '\$resource'];
    function ${appNameVar}Controller(${appName}, \$resource){
    	var vm 							= this;
		vm.${appNameVar}				= {};
		
		function _init(){
			vm.${appNameVar} = ${appName}.get({ id:1 });
		};
    	_init();
    };
})();
/*----PLEASE DO NOT WRITE ANY JS CODE BELOW THIS LINE----*/